#include <stdlib.h>  
#include <stdio.h>
#include <malloc.h>
#include <locale.h>
#pragma warning(disable:4996)
void Print (int arr[], int n)
{
	int i;
	for (i=0; i<n; i++)
	{
		printf("%i ", arr[i]);
	}
	printf("\n");
}
void BubbleSortReal1 (int arr[], int n)
{
	int acc;
	int i, j;
    for (i = 1; i < n; i++) 
	{
        for (j = 1; j < n; j++) 
		{
            if (arr[j] < arr[j-1]) 
			{
                acc = arr[j];
                arr[j] = arr[j-1];
                arr[j-1] = acc;
            }
        }
		Print(arr, n);
	}
}
void BubbleSortReal2(int arr[], int n)
{
	int i, j;
	int acc;
    for (i = 1; i < n; i++) 
	{
        for (j = i; j > 0; j--) 
		{
            if (arr[j] < arr[j-1]) 
			{
                acc = arr[j];
                arr[j] = arr[j-1];
                arr[j-1] = acc;
            }
        }
		Print(arr, n);
    }
}
int main(void)
{
	int mas[8] = {5, 9, 3, 7, 1, 4, 2, 8};
	setlocale(LC_ALL, "Russian");
	printf("������ ���������� (��� � �������): \n");
	BubbleSortReal1(mas, 8);
	printf("������ ���������� (����������): \n");
	BubbleSortReal2(mas, 8);
	return 0;
}