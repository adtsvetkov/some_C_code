#pragma warning(disable:4996)
#include <stdio.h>
#include <stdlib.h>
#define N 5
struct student_info
{
	char lastname[50];
	char name[50];
	int year;
	struct grade
	{
		int math;
		int phys;
		int com_sci;
	} grade;
}student_info;
int main()
{
	struct student_info students[N];
	int i;
	int grades;
	int num=0;
	grades = -1;
	printf("Enter student's lastname, name, year of study, grades in math, physics and comp. science \n");
	for (i = 0; i < N; i++)
	{
		scanf("%s %s %d %d %d %d", &students[i].lastname, &students[i].name, &students[i].year, &students[i].grade.math, &students[i].grade.phys, &students[i].grade.com_sci);

		if (students[i].year == 2 && grades==-1)
		{
			grades = students[i].grade.math + students[i].grade.phys + students[i].grade.com_sci;
			num = i;
		}
		else if (students[i].year == 2)
		{
			if (students[i].grade.math + students[i].grade.phys + students[i].grade.com_sci < grades)
			{
				grades = students[i].grade.math + students[i].grade.phys + students[i].grade.com_sci;
				num = i;
			}
		}
	}

	if (grades != -1)
	{
		printf("\nThe worst student in the second year: %s %s", students[num].lastname, students[num].name);
	}
	else { printf("\nNo second-year students\n"); 
	return 0;
	}

	printf("\nStudents with worse grades:\n\n");

	for (i = 0; i < N; i++)
	{
		if (num!=i && students[i].grade.math + students[i].grade.phys + students[i].grade.com_sci <= grades)
		{
			printf("%s %s\n", students[i].lastname, students[i].name);
		}
	}
	return 0;
}