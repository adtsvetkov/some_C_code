#include <stdlib.h>  
#include <stdio.h>
#include <malloc.h>
#include <locale.h>
#pragma warning(disable:4996)
#define S1 10
#define S2 8
void CreateMas(int a[], int b[], int *c[], int s1, int s2)
{
	int i=0, j=0, k=s2-1;
	do
	{
		if ((a[j] <= b[k]) && (j<s1))
		{
			c[i] = &a[j];
			j++;
		}
		else if (k>=0)
		{
			c[i] = &b[k];
			k--;
		}
		i++;
		if ((k < 0) && (j<s1))
		{
			do
			{
				c[i] = &a[j];
				j++;
				i++;
			}
			while (i<(s1+s2));
		}
		if ((j == s1) && (k>=0))
		{
			do
			{
				c[i] = &b[k];
				k--;
				i++;
			}
			while (i<(s1+s2));
		}
	} while (i<(s1+s2));
}
void Print(int *c[], int n)
{
	int i;
	for (i=0; i<n; i++)
	{
		printf("%i ", *c[i]);
	}
}
int main(void)
{
	int A[S1] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	int B[S2] = {18, 18, 18, 8, 8, 6, 4, 2};
	int *C[S1+S2];
	CreateMas(A, B, C, S1, S2);
	Print(C, S1+S2);
	setlocale(LC_ALL, "Russian");
	return 0;
}